package com.example.week07_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.week07_1.databinding.ActivitySubBinding

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = ActivitySubBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val id = intent.getStringExtra("id")
        val name = intent.getStringExtra("name")
        val gender = intent.getStringExtra("gender")

        binding.ids.text = id
        binding.nas.text = name
        binding.ges.text = gender
    }
}