package com.example.week07_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.week07_1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btn1.setOnClickListener {
            val id = binding.idt.text.toString()
            val name = binding.nat.text.toString()
            val gender = if (binding.men.isChecked) "남성" else "여성"

            val intent = Intent(this, SubActivity::class.java).apply {
                putExtra("id", id)
                putExtra("name", name)
                putExtra("gender", gender)
            }
            startActivity(intent)
        }
    }
}