package com.example.week07_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.week07_1.databinding.ActivitySubBinding

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = ActivitySubBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}