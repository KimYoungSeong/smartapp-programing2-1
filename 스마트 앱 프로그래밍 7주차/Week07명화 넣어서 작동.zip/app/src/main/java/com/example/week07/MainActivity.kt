package com.example.week07

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.week07.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btn1.setOnClickListener {
            var intent = Intent(applicationContext, SubActivity::class.java)//이런 형식
            startActivity(intent)
        }
        binding.iv1.setOnClickListener {
            var intent = Intent(applicationContext, SubActivity::class.java)
            intent.putExtra("imgNumber",R.drawable.pic1)
            intent.putExtra("title",binding.iv1.tag.toString())
            startActivity(intent)
        }
        binding.iv2.setOnClickListener {
            var intent = Intent(applicationContext, SubActivity::class.java)
            intent.putExtra("imgNumber",R.drawable.pic2)
            intent.putExtra("title",binding.iv2.tag.toString())
            startActivity(intent)
        }
    }
}