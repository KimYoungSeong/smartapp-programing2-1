package com.example.week07

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.week07.databinding.ActivitySubBinding

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = ActivitySubBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var imgId = intent.getIntExtra("imgNumber", 0)
        binding.ivDetail.setImageResource(imgId)

        var title = intent.getStringExtra("title")
        binding.tvTitle.text = title

        binding.btn2.setOnClickListener{
            finish()
        }
    }
}