package com.example.week09_1

import android.app.TabActivity
import android.os.Bundle
import com.example.week09_2.R
import com.example.week09_2.databinding.ActivityMainBinding

@Suppress("deprecation")
class MainActivity : TabActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var tabHost = this.tabHost

        var tabSpecmenu = tabHost.newTabSpec("menu").setIndicator("메뉴")
        tabSpecmenu.setContent(R.id.menu)
        tabHost.addTab(tabSpecmenu)
        var tabSpecreview = tabHost.newTabSpec("review").setIndicator("리뷰")
        tabSpecreview.setContent(R.id.review)
        tabHost.addTab(tabSpecreview)
        var tabSpecinformation = tabHost.newTabSpec("information").setIndicator("정보")
        tabSpecinformation.setContent(R.id.information)
        tabHost.addTab(tabSpecinformation)

        tabHost.currentTab = 0

        binding.ViewFlipper1.flipInterval = 1000

        binding.ViewFlipper1.startFlipping()

    }
}