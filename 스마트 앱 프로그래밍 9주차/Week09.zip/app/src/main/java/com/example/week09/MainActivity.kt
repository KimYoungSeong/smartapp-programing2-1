package com.example.week09

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import com.example.week09.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    var selectyear : Int = 0
    var selectMonth : Int = 0
    var selectDay : Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rdoCal.setOnClickListener {
            binding.timePicker1.visibility = View.INVISIBLE
            binding.calendarView1.visibility = View.VISIBLE
        }
        binding.rdoTime.setOnClickListener {
         binding.timePicker1.visibility = View.VISIBLE
         binding.calendarView1.visibility = View.INVISIBLE
        }
        binding.btnStart.setOnClickListener{
            binding.chronometer1.base = SystemClock.elapsedRealtime()
            binding.chronometer1.start()
            binding.chronometer1.setTextColor(Color.RED)
        }
        binding.btnEnd.setOnClickListener {
            binding.chronometer1.stop()
            binding.chronometer1.setTextColor(Color.BLUE)

            binding.tvYear.text = Integer.toString(this.selectyear)
            binding.tvMonth.text = Integer.toString(this.selectMonth)
            binding.tvDay.text = Integer.toString(this.selectDay)

            binding.tvHour.text = Integer.toString(binding.timePicker1.hour)
            binding.tvMinute.text = Integer.toString(binding.timePicker1.minute)
        }
        binding.calendarView1.setOnDateChangeListener { view, year, month, dayOfMonth ->
            this.selectyear = year
            this.selectMonth = month + 1
            this.selectDay = dayOfMonth
        }
    }
}