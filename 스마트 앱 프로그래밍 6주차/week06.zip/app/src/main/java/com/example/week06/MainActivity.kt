package com.example.week06

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.week06.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)

        var etNum1 : EditText = findViewById(R.id.etNum1)
        var etNum2 : EditText = findViewById(R.id.etNum2)

        var btnAdd : Button = findViewById(R.id.btnAdd)
        var btnMin : Button = findViewById(R.id.btnMin)
        var btnMul : Button = findViewById(R.id.btnMul)
        var btnDiv : Button = findViewById(R.id.btnDiv)

        var tvResult : TextView = findViewById(R.id.tvResult)

        var cb1 : CheckBox = findViewById(R.id.cb1)

        binding.rg.setOnCheckedChangeListener { group, checkedId ->
            when(checkedId){
                R.id.rb1 -> Toast.makeText(this@MainActivity, binding.rb1.text.toString(), Toast.LENGTH_SHORT).show()
                R.id.rb2 -> Toast.makeText(this@MainActivity, binding.rb2.text.toString(), Toast.LENGTH_SHORT).show()
                R.id.rb3 -> Toast.makeText(this@MainActivity, binding.rb3.text.toString(), Toast.LENGTH_SHORT).show()
                R.id.rb4 -> Toast.makeText(this@MainActivity, binding.rb4.text.toString(), Toast.LENGTH_SHORT).show()
            }
        }

        btnAdd.setOnClickListener{
            if(etNum1.text.toString().length==0)
                Toast.makeText(this@MainActivity, "숫자를 입력해 주세요.",Toast.LENGTH_SHORT).show()
            var num1 = Integer.parseInt(etNum1.text.toString())
            var num2 = Integer.parseInt(etNum2.text.toString())
            var result = num1 + num2
            tvResult.text = "계산결과 : " + result.toString()
        }
        btnMin.setOnClickListener{
            if(etNum1.text.toString().length==0)
                Toast.makeText(this@MainActivity, "숫자를 입력해 주세요.",Toast.LENGTH_SHORT).show()
            var num1 = Integer.parseInt(etNum1.text.toString())
            var num2 = Integer.parseInt(etNum2.text.toString())
            var result = num1 - num2
            tvResult.text = "계산결과 : " + result.toString()
        }
        btnMul.setOnClickListener{
            if(etNum1.text.toString().length==0)
                Toast.makeText(this@MainActivity, "숫자를 입력해 주세요.",Toast.LENGTH_SHORT).show()
            var num1 = Integer.parseInt(etNum1.text.toString())
            var num2 = Integer.parseInt(etNum2.text.toString())
            var result = num1 * num2
            tvResult.text = "계산결과 : " + result.toString()
        }
        btnDiv.setOnClickListener{
            if(etNum1.text.toString().length==0)
                Toast.makeText(this@MainActivity, "숫자를 입력해 주세요.",Toast.LENGTH_SHORT).show()
            var num1 = Integer.parseInt(etNum1.text.toString())
            var num2 = Integer.parseInt(etNum2.text.toString())
            var result = num1 / num2
            tvResult.text = "계산결과 : " + result.toString()
        }

        cb1.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                Toast.makeText(this@MainActivity, "약관에 동의되었습니다.", Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this@MainActivity, "약관에 동의가 해제되었습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}