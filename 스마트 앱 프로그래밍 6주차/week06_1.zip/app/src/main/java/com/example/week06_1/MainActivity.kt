package com.example.week06_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import com.example.week06_1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)

        binding.play.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                binding.LL.visibility = View.VISIBLE
                Toast.makeText(this@MainActivity, "애완동물 사진중 하나를 고르세요.", Toast.LENGTH_SHORT).show()
            }
            else{
                binding.LL.visibility = View.INVISIBLE
            }
        }

        binding.btn1.setOnClickListener{
            when(binding.rg.checkedRadioButtonId){
                R.id.rbCat -> binding.cat.setImageResource(R.drawable.cat)
                R.id.rbDog -> binding.cat.setImageResource(R.drawable.dog)
                R.id.rbRabbit -> binding.cat.setImageResource(R.drawable.rabbit)
            }
        }

        /*binding.rg.setOnCheckedChangeListener { group, checkedId ->
            when(checkedId){
                R.id.rbCat -> binding.cat.setImageResource(R.drawable.cat)
                R.id.rbDog -> binding.cat.setImageResource(R.drawable.dog)
                R.id.rbRabbit -> binding.cat.setImageResource(R.drawable.rabbit)
            }
        }
        */

        /*binding.rbCat.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                binding.cat.visibility = View.VISIBLE
                binding.dog.visibility = View.INVISIBLE
                binding.rabbit.visibility = View.INVISIBLE
            }
        }
        binding.rbDog.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                binding.cat.visibility = View.INVISIBLE
                binding.dog.visibility = View.VISIBLE
                binding.rabbit.visibility = View.INVISIBLE
            }
        }
        binding.rbRabbit.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                binding.cat.visibility = View.INVISIBLE
                binding.dog.visibility = View.INVISIBLE
                binding.rabbit.visibility = View.VISIBLE
            }
        }*/

    }
}