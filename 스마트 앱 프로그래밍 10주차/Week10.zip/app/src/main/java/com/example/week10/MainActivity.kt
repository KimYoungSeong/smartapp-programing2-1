package com.example.week10

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.week10.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btn3.setOnClickListener {
            var dialogView = View.inflate(this@MainActivity, R.layout.diallog1, null)
            var dig  = AlertDialog.Builder(this@MainActivity)
                .setTitle("사용자 정보 입력")
                .setIcon(R.mipmap.ic_launcher_round)
                .setView(dialogView)
                .setPositiveButton("확인",DialogInterface.OnClickListener { dialog, which ->
                    var dlgname = dialogView.findViewById<EditText>(R.id.nameEt)
                    var dlgmail = dialogView.findViewById<EditText>(R.id.emailEt)
                    binding.nameTv.text = dlgname.text
                    binding.emailTv.text = dlgmail.text

                    var textName = TextView(applicationContext)
                    textName.text = dlgname.text
                    textName.textSize = 30f
                    binding.ll.addView(textName)

                    var textEmail = TextView(applicationContext)
                    textEmail.text = dlgmail.text
                    textEmail.textSize = 30f
                    binding.ll.addView(textEmail)

                })
                .setNegativeButton("취소",null)
                .show()
        }

        binding.btn1.setOnClickListener{
            var dlg = AlertDialog.Builder(this@MainActivity)
            dlg.setTitle("제목입니다.")
            dlg.setMessage("이곳에 내용을 적어주세요")
            dlg.setIcon(R.mipmap.ic_launcher)
            dlg.setPositiveButton("YES", DialogInterface.OnClickListener { dialog, which ->
                Toast.makeText(this@MainActivity, "전화를 걸겠습니다.", Toast.LENGTH_LONG).show()
            })
            dlg.setNegativeButton("NO",DialogInterface.OnClickListener { dialog, which ->
                Toast.makeText(this@MainActivity, "취소 하겠습니다.", Toast.LENGTH_LONG).show()
            })
            dlg.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val mInflater = menuInflater
        mInflater.inflate(R.menu.menu1, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.itemRed -> {
                binding.baseLayout.setBackgroundColor(Color.RED)
                var intent = Intent(applicationContext, TwoActivity::class.java)
                startActivity(intent)
                return true
            }
            R.id.itemGreen -> {
                binding.baseLayout.setBackgroundColor(Color.GREEN)
                return true
            }
            R.id.itemBlue -> {
                binding.baseLayout.setBackgroundColor(Color.BLUE)
                return true
            }
            R.id.itemLotate -> {
                binding.btn1.rotation = 45f
                return true
            }
            R.id.itemSize -> {
                binding.btn1.scaleX = 2f
                return true
            }
        }
        return false
    }
}