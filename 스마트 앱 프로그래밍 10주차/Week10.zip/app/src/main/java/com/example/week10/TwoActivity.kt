package com.example.week10

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import com.example.week10.databinding.ActivityMainBinding
import com.example.week10.databinding.ActivityTwoBinding

class TwoActivity : AppCompatActivity() {

    lateinit var binding : ActivityTwoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTwoBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        var mInflater = menuInflater
        if(v===binding.btn2){
            menu!!.setHeaderTitle("배경색 변경")
            mInflater.inflate(R.menu.menu1, menu)
        }
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.itemRed -> {
                binding.root.setBackgroundColor(Color.RED)
                return true
            }
            R.id.itemGreen -> {
                binding.root.setBackgroundColor(Color.GREEN)
                return true
            }
            R.id.itemBlue -> {
                binding.root.setBackgroundColor(Color.BLUE)
                return true
            }
            R.id.itemLotate -> {
                return true
            }
            R.id.itemSize -> {
                return true
            }
        }
        return false
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val mInflater = menuInflater
        mInflater.inflate(R.menu.menu1, menu)
        return true
    }
}