package com.example.week05

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var menu : Button = findViewById<Button>(R.id.menu)
        var menu1 : ScrollView = findViewById(R.id.menu1)

        var info : Button = findViewById(R.id.info)
        var info1 : LinearLayout = findViewById(R.id.info1)

        var review : Button = findViewById(R.id.review)
        var review1 : LinearLayout = findViewById(R.id.review1)

        menu.setOnClickListener{
            info1.visibility = View.INVISIBLE
            review1.visibility = View.INVISIBLE
            menu1.visibility = View.VISIBLE
        }
        info.setOnClickListener{
            info1.visibility = View.VISIBLE
            review1.visibility = View.INVISIBLE
            menu1.visibility = View.INVISIBLE
        }
        review.setOnClickListener{
            info1.visibility = View.INVISIBLE
            review1.visibility = View.VISIBLE
            menu1.visibility = View.INVISIBLE
        }
    }
}