package com.example.week05

fun main(){
    var myAge : Int = 20
    var myName : String = "조강홍"
    var mynumber = 20010307

    val myval : Int = 100

    println(myAge)
    println(myName)
}